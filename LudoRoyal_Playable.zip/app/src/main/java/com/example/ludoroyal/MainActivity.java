package com.example.ludoroyal;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    GameView v;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        v=new GameView(this); setContentView(v);
    }

    class GameView extends View {
        Paint p=new Paint(3); Random rnd=new Random();
        final int[] C={Color.rgb(225,55,55),Color.rgb(45,180,85),Color.rgb(250,195,35),Color.rgb(55,105,220)};
        int turn=0,dice=1; boolean game=false; boolean rolled=false;
        int[][] steps=new int[4][4]; // -1 yard, 0..56 track, 57 home
        int[] selected={-1,-1,-1,-1};
        final int[] start={0,13,26,39};
        GameView(Context c){super(c);p.setTypeface(Typeface.create("sans",Typeface.BOLD));}

        void fill(Canvas c,int col){p.setStyle(Paint.Style.FILL);p.setColor(col);}
        void stroke(Canvas c,int col,float sw){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);p.setColor(col);}
        void text(Canvas c,String s,float x,float y,float sz,int col){
            fill(c,col);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(sz);c.drawText(s,x,y,p);
        }
        void rr(Canvas c,float l,float t,float r,float b,float rad,int col){
            fill(c,col);c.drawRoundRect(l,t,r,b,rad,rad,p);stroke(c,Color.rgb(255,205,35),3);c.drawRoundRect(l,t,r,b,rad,rad,p);
        }
        void circle(Canvas c,float x,float y,float r,int col){fill(c,col);c.drawCircle(x,y,r,p);stroke(c,Color.WHITE,2);c.drawCircle(x,y,r,p);}

        protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight();
            fill(c,Color.rgb(8,42,100));c.drawRect(0,0,w,h,p);
            for(int y=0;y<h;y+=90)for(int x=0;x<w;x+=90){circle(c,x+20,y+25,9,Color.argb(25,255,255,255));}
            if(!game) home(c,w,h); else board(c,w,h);
        }

        void home(Canvas c,float w,float h){
            fill(c,Color.rgb(4,28,72));c.drawRect(0,0,w,88,p);
            circle(c,43,42,28,Color.LTGRAY);text(c,"⚙",105,55,30,Color.WHITE);text(c,"✉",175,55,29,Color.YELLOW);
            text(c,"💎",310,55,24,Color.WHITE);text(c,"00",365,56,24,Color.WHITE);
            text(c,"🪙",465,55,24,Color.YELLOW);text(c,"00",520,56,24,Color.WHITE);text(c,"🛒",650,58,29,Color.YELLOW);
            text(c,"♛",w/2,178,65,Color.YELLOW);
            String[] l={"L","U","D","O"}; int[] cc={Color.CYAN,Color.RED,Color.rgb(70,200,90),Color.YELLOW};
            for(int i=0;i<4;i++)text(c,l[i],w/2-105+i*70,240,50,cc[i]);
            text(c,"ROYAL",w/2,275,22,Color.YELLOW);
            float bx=w/2-105,by=295;rr(c,bx,by,bx+210,by+130,8,Color.WHITE);
            for(int i=0;i<4;i++){fill(c,cc[i]);c.drawRect(bx+i*52,by,bx+i*52+52,by+42,p);}
            text(c,"⚄",w/2,by+94,58,Color.DKGRAY);circle(c,bx-34,by+108,30,Color.CYAN);circle(c,bx+244,by+108,30,Color.YELLOW);
            button(c,55,420,w/2-8,535,"🌐  ONLINE");button(c,w/2+8,420,w-55,535,"⚔  TEAM UP");
            button(c,55,550,w/2-8,665,"❤  FRIENDS");button(c,w/2+8,550,w-55,665,"VS  COMPUTER");
            button(c,135,680,w-135,790,"👥  PASS N PLAY");
            text(c,"♛  TOURNAMENT",w/2,875,30,Color.YELLOW);
            rr(c,w/2-145,900,w/2+145,965,18,Color.rgb(18,100,205));text(c,"SEASON 1 • COMING SOON",w/2,941,16,Color.WHITE);
            fill(c,Color.rgb(3,35,85));c.drawRect(0,h-88,w,h,p);
            String[] n={"⌂","★","♫","◉","☁"};String[] t={"HOME","EVENT","VOICE","INVENTORY","SOCIAL"};
            for(int i=0;i<5;i++){float x=w*(i+.5f)/5;text(c,n[i],x,h-48,28,i==0?Color.YELLOW:Color.WHITE);text(c,t[i],x,h-18,12,Color.WHITE);}
        }
        void button(Canvas c,float l,float t,float r,float b,String s){rr(c,l,t,r,b,24,Color.rgb(20,105,220));text(c,s,(l+r)/2,(t+b)/2+8,19,Color.WHITE);}

        void board(Canvas c,float w,float h){
            text(c,"LUDO ROYAL",w/2,38,27,Color.YELLOW);
            text(c,"PLAYER "+(turn+1)+"'S TURN",w/2,70,17,Color.WHITE);
            float size=Math.min(w-18,h-205),ox=(w-size)/2,oy=92,cell=size/15;
            // 15x15 board
            for(int y=0;y<15;y++)for(int x=0;x<15;x++){
                int col=Color.WHITE;
                if(x<6&&y<6)col=C[0]; if(x>8&&y<6)col=C[1]; if(x<6&&y>8)col=C[2]; if(x>8&&y>8)col=C[3];
                if((x>=6&&x<=8)||(y>=6&&y<=8))col=Color.WHITE;
                fill(c,col);c.drawRect(ox+x*cell,oy+y*cell,ox+(x+1)*cell,oy+(y+1)*cell,p);
                stroke(c,Color.GRAY,1);c.drawRect(ox+x*cell,oy+y*cell,ox+(x+1)*cell,oy+(y+1)*cell,p);
            }
            // center
            fill(c,Color.LTGRAY);c.drawRect(ox+6*cell,oy+6*cell,ox+9*cell,oy+9*cell,p);
            // home circles
            for(int pl=0;pl<4;pl++)for(int k=0;k<4;k++){
                float x=ox+(pl%2==0?2:12)*cell+(k%2==0?-cell*.7f:cell*.7f);
                float y=oy+(pl<2?2:12)*cell+(k/2==0?-cell*.7f:cell*.7f);
                circle(c,x,y,cell*.34f,C[pl]);
            }
            // track highlight
            for(int i=0;i<4;i++){
                int[] xy=track(i,0,ox,oy,cell);
            }
            // tokens on track/home
            for(int pl=0;pl<4;pl++)for(int k=0;k<4;k++){
                int s=steps[pl][k];
                float x,y;
                if(s<0){x=ox+(pl%2==0?2:12)*cell+(k%2==0?-cell*.7f:cell*.7f);y=oy+(pl<2?2:12)*cell+(k/2==0?-cell*.7f:cell*.7f);}
                else if(s>=57){x=w/2+(k-1.5f)*cell*.7f;y=oy+7.5f*cell;}
                else {int[] q=track(pl,s,ox,oy,cell);x=q[0];y=q[1];}
                circle(c,x,y,cell*.28f,C[pl]);
            }
            rr(c,w/2-58,h-105,w/2+58,h-48,18,Color.rgb(20,65,120));
            text(c,""+dice,w/2,h-68,29,Color.WHITE);text(c,"TAP DICE",w/2,h-18,14,Color.YELLOW);
            if(rolled) text(c,"Tap a token to move",w/2,h-132,14,Color.WHITE);
        }

        int[] track(int pl,int s,float ox,float oy,float cell){
            // shared 52-cell perimeter path, compact Ludo-like
            int idx=(start[pl]+s)%52;
            int x,y;
            if(idx<13){x=6+idx;y=6;}
            else if(idx<26){x=8;y=6+(idx-13);}
            else if(idx<39){x=8-(idx-26);y=8;}
            else {x=6;y=8-(idx-39);}
            return new int[]{(int)(ox+(x+.5f)*cell),(int)(oy+(y+.5f)*cell)};
        }
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(!game){
                if(y>400&&y<820){game=true;invalidate();}
            }else if(y>h-130){
                dice=1+rnd.nextInt(6);rolled=true;invalidate();
            }else if(rolled){
                // Move first legal token on any tap in board area.
                int chosen=-1;
                for(int k=0;k<4;k++){
                    if(steps[turn][k]<0 && dice==6){chosen=k;break;}
                    if(steps[turn][k]>=0 && steps[turn][k]<57 && steps[turn][k]+dice<=57){chosen=k;break;}
                }
                if(chosen>=0){
                    if(steps[turn][chosen]<0)steps[turn][chosen]=0; else steps[turn][chosen]+=dice;
                    if(steps[turn][chosen]<57) capture(turn,chosen);
                    if(dice!=6)turn=(turn+1)%4;
                    rolled=false;invalidate();
                }
            }
            return true;
        }
        void capture(int pl,int tok){
            int[] a=track(pl,steps[pl][tok],0,0,1);
            for(int q=0;q<4;q++)for(int k=0;k<4;k++)if(q!=pl&&steps[q][k]>=0&&steps[q][k]<57){
                int[] b=track(q,steps[q][k],0,0,1);
                if(a[0]==b[0]&&a[1]==b[1])steps[q][k]=-1;
            }
        }
    }
}